list_target = open("../zoned-scrapper/result/urls.txt", "r")
list_domain = open("domain.txt", "r")
x = set(list_domain)
xx = set(list_target)
for z in x:
    z = z.strip()
    for zz in xx:
        zz = zz.strip()
        if z in zz:
            zh = zz.replace("http://","").replace("https://","").replace(z, "")
            print("http://"+zh)
        else:
            pass
        #open("urls.txt","a").write(target+'\n')
